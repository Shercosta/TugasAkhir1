let documentID = new Date().getMilliseconds();

document.getElementById("docid").value = documentID;
